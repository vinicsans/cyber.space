//
//  File.swift
//  
//
//  Created by user on 17/02/24.
//

import Foundation

struct DraggableItem: Hashable {
    let id = UUID()
    let content: String
}
